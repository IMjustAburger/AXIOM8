AXIOM7 repair kit
=================

This bundle addresses the two confirmed build-pipeline issues:
1. The workflow referenced axiom-2.0.1-src.zip, but the repository contains AXIOM6-fixed-source.zip.
2. The corrected source ZIP contains the missing java.util.Collection import in StashFinder.java.

Files:
- .github/workflows/build.yml : corrected workflow; it reads AXIOM6-fixed-source.zip and names the artifact AXIOM-2.0.2.
- AXIOM6-fixed-source.zip : corrected AXIOM 2.0.2 source archive.

To apply in GitHub:
1. Keep AXIOM6-fixed-source.zip in the repository root.
2. Open .github/workflows/build.yml, click Edit, replace its contents with the bundled build.yml, and commit to main.
3. The commit triggers a new Actions run. Check that Build and test passes and AXIOM-2.0.2 is uploaded.

The repair fixes the exact observed extraction failure and the previously observed missing import. It does not claim a successful build until GitHub Actions completes successfully.
